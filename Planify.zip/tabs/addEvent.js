import React, { Fragment,Text } from 'react'
import {Form,Button,Card } from 'react-bootstrap'

function addEvent() {
    return (
        <Text>Salut</Text>
    )
}
