import React, { useContext, useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Image,
  Platform,
  StyleSheet,
  ScrollView
} from 'react-native';

const MainPageScreen = ({ navigation }) => {
    return (
        <Text>Main page !</Text>
    );
};

export default MainPageScreen;
