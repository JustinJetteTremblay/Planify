Modules a installer avant de commencer:

npm i react-native-onboarding-swiper

npm install @react-navigation/native

expo install react-native-screens react-native-safe-area-context

npm install @react-navigation/native-stack

npm install @react-native-async-storage/async-storage

npm install --save react-native-vector-icons

npm install --save @react-native-firebase/app

npm install --save firebase

expo install firebase

expo install react-native-svg

npm i styled-system

npm install --save styled-components

npm install use-theme

npm install native-base@2.15.2 --force

npm install --save react-native-textarea

npm install react-native-google-places-autocomplete

npm i -S @react-google-maps/api

--------2021-11-01---------
npm install @react-native-community/geolocation --save
npm install react-native link @react-native-community/geolocation
npm install --save react-native-calendars

npm install react-native-camera --save
npm install react-native-image-picker --save

